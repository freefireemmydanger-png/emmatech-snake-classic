package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val RetroColorScheme = darkColorScheme(
    primary = LcdPixel,
    onPrimary = LcdBackground,
    secondary = KeypadAccent,
    onSecondary = PhoneBodyDark,
    background = PhoneBodyDark,
    onBackground = KeypadButtonText,
    surface = PhoneBodyNavy,
    onSurface = KeypadButtonText,
    surfaceVariant = PhoneBezel,
    onSurfaceVariant = KeypadButtonText
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = RetroColorScheme,
        typography = Typography,
        content = content
    )
}
