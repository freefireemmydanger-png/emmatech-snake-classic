package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Authentic Monochrome Green Nokia 3310 LCD Palette
val LcdBackground = Color(0xFF97B272)
val LcdBackgroundLight = Color(0xFFA5C17F)
val LcdBackgroundDark = Color(0xFF869E5F)
val LcdPixel = Color(0xFF142410)
val LcdPixelInactive = Color(0x22142410)
val LcdBorder = Color(0xFF1A2F15)

// Retro Nokia Phone Chassis & Hardware
val PhoneBodyDark = Color(0xFF1F2937)
val PhoneBodyNavy = Color(0xFF2C3E55)
val PhoneBodyHighlight = Color(0xFF3C5069)
val PhoneBezel = Color(0xFF17202B)
val PhoneSilverTrim = Color(0xFFB0BAC5)
val KeypadButtonDark = Color(0xFF334458)
val KeypadButtonLight = Color(0xFF435870)
val KeypadButtonText = Color(0xFFE2E8F0)
val KeypadAccent = Color(0xFF38BDF8)
val KeypadAccentAmber = Color(0xFFFBBF24)
val KeypadDanger = Color(0xFFEF4444)
val KeypadSuccess = Color(0xFF22C55E)
