package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.snake.ui.RetroPhoneFrame
import com.example.snake.viewmodel.SnakeViewModel
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.PhoneBodyDark

class MainActivity : ComponentActivity() {

    private val snakeViewModel: SnakeViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(PhoneBodyDark),
                    contentWindowInsets = WindowInsets.safeDrawing
                ) { innerPadding ->
                    val gameState by snakeViewModel.gameState.collectAsStateWithLifecycle()

                    RetroPhoneFrame(
                        gameState = gameState,
                        onDirectionChange = { dir -> snakeViewModel.handleDirectionInput(dir) },
                        onStartGame = { snakeViewModel.startGame() },
                        onPauseGame = { snakeViewModel.pauseGame() },
                        onResumeGame = { snakeViewModel.resumeGame() },
                        onRestartGame = { snakeViewModel.restartGame() },
                        onToggleSound = { snakeViewModel.toggleSound() },
                        onToggleHaptics = { snakeViewModel.toggleHaptics() },
                        onToggleWallPass = { snakeViewModel.toggleWallPassThrough() },
                        onSelectDifficulty = { diff -> snakeViewModel.setDifficulty(diff) },
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    )
                }
            }
        }
    }
}
