package com.example.snake.audio

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.CombinedVibration
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log

/**
 * Provides nostalgic retro 8-bit audio feedback and tactile haptic vibration
 * replicating the classic Nokia 3310 speaker buzzer and keypad tactile clicks.
 */
class RetroAudioHelper(context: Context) {

    private val appContext = context.applicationContext
    private var toneGenerator: ToneGenerator? = null

    private val vibrator: Vibrator? = try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = appContext.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vibratorManager?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            appContext.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    } catch (e: Exception) {
        null
    }

    init {
        try {
            toneGenerator = ToneGenerator(AudioManager.STREAM_MUSIC, 70)
        } catch (e: Exception) {
            Log.w("RetroAudioHelper", "Failed to initialize ToneGenerator", e)
        }
    }

    /**
     * Short high beep when snake eats food.
     */
    fun playFoodSound() {
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_PROP_ACK, 80)
        } catch (e: Exception) {
            // Ignore sound errors
        }
    }

    /**
     * Subtle click on direction change.
     */
    fun playTurnSound() {
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP2, 25)
        } catch (e: Exception) {
            // Ignore sound errors
        }
    }

    /**
     * Low buzz on game over crash.
     */
    fun playGameOverSound() {
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_PROP_NACK, 260)
        } catch (e: Exception) {
            // Ignore sound errors
        }
    }

    /**
     * Tactile key click sound for buttons.
     */
    fun playButtonClickSound() {
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP, 30)
        } catch (e: Exception) {
            // Ignore sound errors
        }
    }

    /**
     * Keypad haptic feedback.
     */
    fun vibrateKeyClick() {
        vibrate(20)
    }

    /**
     * Food eat haptic feedback.
     */
    fun vibrateEatFood() {
        vibrate(40)
    }

    /**
     * Crash haptic feedback.
     */
    fun vibrateGameOver() {
        vibrate(200)
    }

    private fun vibrate(durationMs: Long) {
        try {
            vibrator?.let { v ->
                if (v.hasVibrator()) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        v.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
                    } else {
                        @Suppress("DEPRECATION")
                        v.vibrate(durationMs)
                    }
                }
            }
        } catch (e: Exception) {
            // Ignore vibration errors
        }
    }

    fun release() {
        try {
            toneGenerator?.release()
            toneGenerator = null
        } catch (e: Exception) {
            // Ignore
        }
    }
}
