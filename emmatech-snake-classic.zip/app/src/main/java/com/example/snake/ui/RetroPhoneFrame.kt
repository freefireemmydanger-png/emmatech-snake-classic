package com.example.snake.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.snake.model.Difficulty
import com.example.snake.model.Direction
import com.example.snake.model.SnakeGameState
import com.example.ui.theme.PhoneBezel
import com.example.ui.theme.PhoneBodyDark
import com.example.ui.theme.PhoneBodyHighlight
import com.example.ui.theme.PhoneBodyNavy
import com.example.ui.theme.PhoneSilverTrim
import com.example.ui.theme.PixelFontFamily

/**
 * Nostalgic Nokia phone body enclosing the LCD screen and physical controls.
 * Automatically adapts across small screens, standard phones, and tablets.
 */
@Composable
fun RetroPhoneFrame(
    gameState: SnakeGameState,
    onDirectionChange: (Direction) -> Unit,
    onStartGame: () -> Unit,
    onPauseGame: () -> Unit,
    onResumeGame: () -> Unit,
    onRestartGame: () -> Unit,
    onToggleSound: () -> Unit,
    onToggleHaptics: () -> Unit,
    onToggleWallPass: () -> Unit,
    onSelectDifficulty: (Difficulty) -> Unit,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(PhoneBodyDark),
        contentAlignment = Alignment.Center
    ) {
        val isLandscape = maxWidth > maxHeight
        val isLargeScreen = maxWidth > 600.dp

        if (isLandscape) {
            // Side-by-side layout for Landscape / Tablets / Foldables
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp)
                    .clip(RoundedCornerShape(28.dp))
                    .background(
                        Brush.horizontalGradient(
                            listOf(PhoneBodyNavy, PhoneBodyHighlight, PhoneBodyNavy)
                        )
                    )
                    .border(3.dp, PhoneSilverTrim.copy(alpha = 0.5f), RoundedCornerShape(28.dp))
                    .padding(12.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // LCD Screen on the Left
                Box(
                    modifier = Modifier
                        .weight(1.2f)
                        .fillMaxHeight(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxSize()
                    ) {
                        EarpieceSpeaker()
                        PhoneBrandHeader()
                        LcdGameScreen(
                            gameState = gameState,
                            onDirectionChange = onDirectionChange,
                            onStartGame = onStartGame,
                            onPauseGame = onPauseGame,
                            onResumeGame = onResumeGame,
                            onRestartGame = onRestartGame,
                            onToggleSound = onToggleSound,
                            onToggleWallPass = onToggleWallPass,
                            onSelectDifficulty = onSelectDifficulty,
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                        )
                    }
                }

                // Keypad on the Right
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                    contentAlignment = Alignment.Center
                ) {
                    PhoneKeypad(
                        gameStatus = gameState.status,
                        soundEnabled = gameState.soundEnabled,
                        hapticsEnabled = gameState.hapticsEnabled,
                        onDirectionClick = onDirectionChange,
                        onStartClick = onStartGame,
                        onPauseClick = onPauseGame,
                        onResumeClick = onResumeGame,
                        onRestartClick = onRestartGame,
                        onToggleSound = onToggleSound,
                        onToggleHaptics = onToggleHaptics
                    )
                }
            }
        } else {
            // Portrait Mobile Layout (Classic Nokia Handset Frame)
            val phoneBodyModifier = if (isLargeScreen) {
                Modifier
                    .widthIn(max = 480.dp)
                    .fillMaxHeight()
                    .padding(vertical = 8.dp)
            } else {
                Modifier.fillMaxSize()
            }

            Box(
                modifier = phoneBodyModifier
                    .clip(RoundedCornerShape(32.dp))
                    .background(
                        Brush.verticalGradient(
                            listOf(PhoneBodyNavy, PhoneBodyHighlight, PhoneBodyNavy)
                        )
                    )
                    .border(3.dp, PhoneSilverTrim.copy(alpha = 0.5f), RoundedCornerShape(32.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    // Top Section: Earpiece & Nokia-style Brand Logo
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(top = 4.dp, bottom = 2.dp)
                    ) {
                        EarpieceSpeaker()
                        PhoneBrandHeader()
                    }

                    // Middle Section: LCD Display (fixed aspect ratio for nostalgic CRT/LCD proportion)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f, fill = false)
                            .aspectRatio(1.1f)
                            .padding(horizontal = 4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        LcdGameScreen(
                            gameState = gameState,
                            onDirectionChange = onDirectionChange,
                            onStartGame = onStartGame,
                            onPauseGame = onPauseGame,
                            onResumeGame = onResumeGame,
                            onRestartGame = onRestartGame,
                            onToggleSound = onToggleSound,
                            onToggleWallPass = onToggleWallPass,
                            onSelectDifficulty = onSelectDifficulty,
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // Bottom Section: Physical Keypad & Controls
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        PhoneKeypad(
                            gameStatus = gameState.status,
                            soundEnabled = gameState.soundEnabled,
                            hapticsEnabled = gameState.hapticsEnabled,
                            onDirectionClick = onDirectionChange,
                            onStartClick = onStartGame,
                            onPauseClick = onPauseGame,
                            onResumeClick = onResumeGame,
                            onRestartClick = onRestartGame,
                            onToggleSound = onToggleSound,
                            onToggleHaptics = onToggleHaptics
                        )
                    }
                }
            }
        }
    }
}

/**
 * Top earpiece speaker grill slit.
 */
@Composable
private fun EarpieceSpeaker() {
    Box(
        modifier = Modifier
            .size(width = 56.dp, height = 5.dp)
            .clip(RoundedCornerShape(3.dp))
            .background(PhoneBezel)
            .border(1.dp, PhoneSilverTrim.copy(alpha = 0.3f), RoundedCornerShape(3.dp))
    )
}

/**
 * Nokia style brand banner: "EMMATECH".
 */
@Composable
private fun PhoneBrandHeader() {
    Text(
        text = "EMMATECH",
        fontFamily = PixelFontFamily,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        color = PhoneSilverTrim,
        letterSpacing = 3.sp,
        modifier = Modifier.padding(top = 4.dp, bottom = 4.dp)
    )
}
