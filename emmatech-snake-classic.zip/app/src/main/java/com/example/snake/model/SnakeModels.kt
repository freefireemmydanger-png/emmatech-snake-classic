package com.example.snake.model

/**
 * Represents a discrete grid coordinate on the snake playfield.
 */
data class Coordinate(
    val x: Int,
    val y: Int
)

/**
 * Direction of snake movement.
 */
enum class Direction(val dx: Int, val dy: Int) {
    UP(0, -1),
    DOWN(0, 1),
    LEFT(-1, 0),
    RIGHT(1, 0);

    /**
     * Returns true if [other] is the opposite direction.
     */
    fun isOpposite(other: Direction): Boolean {
        return (this == UP && other == DOWN) ||
                (this == DOWN && other == UP) ||
                (this == LEFT && other == RIGHT) ||
                (this == RIGHT && other == LEFT)
    }
}

/**
 * Game execution states.
 */
enum class GameStatus {
    IDLE,       // Start screen / menu
    RUNNING,    // Active gameplay
    PAUSED,     // Gameplay paused
    GAME_OVER   // Collided with wall or self
}

/**
 * Difficulty / Speed settings.
 */
enum class Difficulty(val label: String, val baseDelayMs: Long, val minDelayMs: Long, val speedStepMs: Long) {
    EASY("Slow", 260L, 110L, 4L),
    CLASSIC("Normal", 200L, 70L, 5L),
    HARD("Fast", 140L, 50L, 4L)
}

/**
 * Immutable state of the game.
 */
data class SnakeGameState(
    val snake: List<Coordinate> = listOf(
        Coordinate(8, 10),
        Coordinate(7, 10),
        Coordinate(6, 10),
        Coordinate(5, 10)
    ),
    val currentDirection: Direction = Direction.RIGHT,
    val food: Coordinate = Coordinate(14, 10),
    val status: GameStatus = GameStatus.IDLE,
    val score: Int = 0,
    val highScore: Int = 0,
    val gridWidth: Int = 20,
    val gridHeight: Int = 18,
    val difficulty: Difficulty = Difficulty.CLASSIC,
    val soundEnabled: Boolean = true,
    val hapticsEnabled: Boolean = true,
    val wallPassThrough: Boolean = false,
    val isNewHighScore: Boolean = false
) {
    val level: Int
        get() = (score / 5) + 1

    val currentDelayMs: Long
        get() {
            val reduced = difficulty.baseDelayMs - (score * difficulty.speedStepMs)
            return reduced.coerceAtLeast(difficulty.minDelayMs)
        }
}
