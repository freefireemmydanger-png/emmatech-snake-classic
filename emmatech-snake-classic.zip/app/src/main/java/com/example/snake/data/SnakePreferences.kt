package com.example.snake.data

import android.content.Context
import android.content.SharedPreferences

/**
 * Manages persistent local data for EMMATECH Snake Classic:
 * - High score
 * - Sound toggle preference
 * - Haptics toggle preference
 * - Difficulty choice
 * - Wall mode choice
 */
class SnakePreferences(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("emmatech_snake_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_HIGH_SCORE = "key_high_score"
        private const val KEY_SOUND_ENABLED = "key_sound_enabled"
        private const val KEY_HAPTICS_ENABLED = "key_haptics_enabled"
        private const val KEY_DIFFICULTY = "key_difficulty"
        private const val KEY_WALL_PASS = "key_wall_pass"
    }

    fun getHighScore(): Int {
        return prefs.getInt(KEY_HIGH_SCORE, 0)
    }

    fun saveHighScore(score: Int) {
        val current = getHighScore()
        if (score > current) {
            prefs.edit().putInt(KEY_HIGH_SCORE, score).apply()
        }
    }

    fun resetHighScore() {
        prefs.edit().putInt(KEY_HIGH_SCORE, 0).apply()
    }

    fun isSoundEnabled(): Boolean {
        return prefs.getBoolean(KEY_SOUND_ENABLED, true)
    }

    fun setSoundEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_SOUND_ENABLED, enabled).apply()
    }

    fun isHapticsEnabled(): Boolean {
        return prefs.getBoolean(KEY_HAPTICS_ENABLED, true)
    }

    fun setHapticsEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_HAPTICS_ENABLED, enabled).apply()
    }

    fun getDifficulty(): String {
        return prefs.getString(KEY_DIFFICULTY, "CLASSIC") ?: "CLASSIC"
    }

    fun setDifficulty(difficulty: String) {
        prefs.edit().putString(KEY_DIFFICULTY, difficulty).apply()
    }

    fun isWallPassThrough(): Boolean {
        return prefs.getBoolean(KEY_WALL_PASS, false)
    }

    fun setWallPassThrough(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_WALL_PASS, enabled).apply()
    }
}
