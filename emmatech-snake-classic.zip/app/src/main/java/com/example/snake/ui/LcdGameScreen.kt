package com.example.snake.ui

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.snake.model.Coordinate
import com.example.snake.model.Difficulty
import com.example.snake.model.Direction
import com.example.snake.model.GameStatus
import com.example.snake.model.SnakeGameState
import com.example.ui.theme.LcdBackground
import com.example.ui.theme.LcdBackgroundDark
import com.example.ui.theme.LcdBackgroundLight
import com.example.ui.theme.LcdBorder
import com.example.ui.theme.LcdFontFamily
import com.example.ui.theme.LcdPixel
import com.example.ui.theme.LcdPixelInactive
import com.example.ui.theme.PixelFontFamily
import kotlin.math.abs

/**
 * The authentic monochrome green LCD screen for EMMATECH Snake Classic.
 * Renders the score, playfield grid, snake, food, scanlines, and retro overlay dialogs.
 */
@Composable
fun LcdGameScreen(
    gameState: SnakeGameState,
    onDirectionChange: (Direction) -> Unit,
    onStartGame: () -> Unit,
    onPauseGame: () -> Unit,
    onResumeGame: () -> Unit,
    onRestartGame: () -> Unit,
    onToggleSound: () -> Unit,
    onToggleWallPass: () -> Unit,
    onSelectDifficulty: (Difficulty) -> Unit,
    modifier: Modifier = Modifier
) {
    // Blinking effect for food and start/game over prompts
    val infiniteTransition = rememberInfiniteTransition(label = "lcd_blink")
    val blinkAlpha by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 0.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 400),
            repeatMode = RepeatMode.Reverse
        ),
        label = "blink_alpha"
    )

    // Gesture tracking for swipe on LCD screen
    var totalDragX by remember { mutableFloatStateOf(0f) }
    var totalDragY by remember { mutableFloatStateOf(0f) }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(LcdBackground)
            .border(3.dp, LcdBorder, RoundedCornerShape(8.dp))
            .pointerInput(gameState.status) {
                detectDragGestures(
                    onDragStart = {
                        totalDragX = 0f
                        totalDragY = 0f
                    },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        totalDragX += dragAmount.x
                        totalDragY += dragAmount.y
                    },
                    onDragEnd = {
                        val threshold = 35f
                        if (abs(totalDragX) > abs(totalDragY)) {
                            if (abs(totalDragX) > threshold) {
                                if (totalDragX > 0) {
                                    onDirectionChange(Direction.RIGHT)
                                } else {
                                    onDirectionChange(Direction.LEFT)
                                }
                            }
                        } else {
                            if (abs(totalDragY) > threshold) {
                                if (totalDragY > 0) {
                                    onDirectionChange(Direction.DOWN)
                                } else {
                                    onDirectionChange(Direction.UP)
                                }
                            }
                        }
                        totalDragX = 0f
                        totalDragY = 0f
                    }
                )
            }
            .testTag("lcd_screen_container")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 6.dp, vertical = 4.dp)
        ) {
            // LCD Top Status Bar
            LcdTopBar(
                score = gameState.score,
                highScore = gameState.highScore,
                level = gameState.level,
                soundEnabled = gameState.soundEnabled,
                wallPass = gameState.wallPassThrough,
                status = gameState.status,
                onToggleSound = onToggleSound
            )

            // Inner LCD Playfield Canvas
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(4.dp))
                    .border(2.dp, LcdBorder, RoundedCornerShape(4.dp))
                    .background(LcdBackground)
            ) {
                // Game Grid Canvas
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("snake_canvas")
                ) {
                    val canvasWidth = size.width
                    val canvasHeight = size.height

                    val cellWidth = canvasWidth / gameState.gridWidth
                    val cellHeight = canvasHeight / gameState.gridHeight

                    // Subtle dot-matrix grid background
                    drawLcdGridDots(
                        width = gameState.gridWidth,
                        height = gameState.gridHeight,
                        cellW = cellWidth,
                        cellH = cellHeight,
                        dotColor = LcdPixelInactive
                    )

                    // Draw Snake Body
                    gameState.snake.forEachIndexed { index, segment ->
                        val isHead = index == 0
                        val left = segment.x * cellWidth
                        val top = segment.y * cellHeight

                        drawSnakeSegment(
                            left = left,
                            top = top,
                            width = cellWidth,
                            height = cellHeight,
                            isHead = isHead,
                            direction = gameState.currentDirection,
                            color = LcdPixel
                        )
                    }

                    // Draw Food (Square dot with inner cutout / classic Nokia food)
                    val foodLeft = gameState.food.x * cellWidth
                    val foodTop = gameState.food.y * cellHeight
                    drawLcdFood(
                        left = foodLeft,
                        top = foodTop,
                        width = cellWidth,
                        height = cellHeight,
                        color = LcdPixel,
                        blink = gameState.status == GameStatus.RUNNING
                    )
                }

                // Status Overlays
                when (gameState.status) {
                    GameStatus.IDLE -> {
                        LcdStartOverlay(
                            highScore = gameState.highScore,
                            difficulty = gameState.difficulty,
                            wallPass = gameState.wallPassThrough,
                            onStart = onStartGame,
                            onToggleWallPass = onToggleWallPass,
                            onSelectDifficulty = onSelectDifficulty,
                            blinkAlpha = blinkAlpha
                        )
                    }
                    GameStatus.PAUSED -> {
                        LcdPausedOverlay(
                            score = gameState.score,
                            onResume = onResumeGame,
                            blinkAlpha = blinkAlpha
                        )
                    }
                    GameStatus.GAME_OVER -> {
                        LcdGameOverOverlay(
                            score = gameState.score,
                            highScore = gameState.highScore,
                            isNewRecord = gameState.isNewHighScore,
                            onRestart = onRestartGame,
                            blinkAlpha = blinkAlpha
                        )
                    }
                    GameStatus.RUNNING -> {
                        // In game: no overlay, full clear gameplay view
                    }
                }
            }
        }
    }
}

/**
 * Top bar displaying score, high score, and level in retro LCD font.
 */
@Composable
private fun LcdTopBar(
    score: Int,
    highScore: Int,
    level: Int,
    soundEnabled: Boolean,
    wallPass: Boolean,
    status: GameStatus,
    onToggleSound: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Score
        Text(
            text = "SCORE:%04d".format(score),
            fontFamily = PixelFontFamily,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = LcdPixel
        )

        // Wall Mode / Status indicator
        Text(
            text = if (wallPass) "WALL:PASS" else "LVL:%d".format(level),
            fontFamily = PixelFontFamily,
            fontSize = 9.sp,
            color = LcdPixel
        )

        // Best
        Text(
            text = "BEST:%04d".format(highScore),
            fontFamily = PixelFontFamily,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = LcdPixel
        )
    }
}

/**
 * Start screen overlay with developer credit "EMMATECHPRO".
 */
@Composable
private fun LcdStartOverlay(
    highScore: Int,
    difficulty: Difficulty,
    wallPass: Boolean,
    onStart: () -> Unit,
    onToggleWallPass: () -> Unit,
    onSelectDifficulty: (Difficulty) -> Unit,
    blinkAlpha: Float
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(LcdBackground.copy(alpha = 0.92f))
            .padding(8.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "EMMATECH",
                fontFamily = PixelFontFamily,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = LcdPixel,
                letterSpacing = 1.sp
            )

            Text(
                text = "SNAKE CLASSIC",
                fontFamily = PixelFontFamily,
                fontSize = 15.sp,
                fontWeight = FontWeight.ExtraBold,
                color = LcdPixel,
                modifier = Modifier.padding(top = 2.dp, bottom = 4.dp)
            )

            // Developer Credit
            Text(
                text = "DEV: EMMATECHPRO",
                fontFamily = PixelFontFamily,
                fontSize = 8.sp,
                color = LcdPixel,
                modifier = Modifier
                    .background(LcdPixelInactive, RoundedCornerShape(2.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Start Prompt (Blinking)
            Text(
                text = "▶ PRESS START ◀",
                fontFamily = PixelFontFamily,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = LcdPixel.copy(alpha = blinkAlpha),
                modifier = Modifier
                    .clickable(onClick = onStart)
                    .testTag("lcd_press_start_text")
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Difficulty toggle chips
            Row(
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Difficulty.values().forEach { diff ->
                    val isSelected = diff == difficulty
                    Text(
                        text = diff.label.uppercase(),
                        fontFamily = PixelFontFamily,
                        fontSize = 8.sp,
                        color = if (isSelected) LcdBackground else LcdPixel,
                        modifier = Modifier
                            .clip(RoundedCornerShape(2.dp))
                            .background(if (isSelected) LcdPixel else Color.Transparent)
                            .border(1.dp, LcdPixel, RoundedCornerShape(2.dp))
                            .clickable { onSelectDifficulty(diff) }
                            .padding(horizontal = 4.dp, vertical = 2.dp)
                            .testTag("difficulty_${diff.name.lowercase()}")
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Wall Mode Toggle
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(2.dp))
                    .clickable { onToggleWallPass() }
                    .padding(horizontal = 4.dp, vertical = 2.dp)
                    .testTag("wall_mode_toggle")
            ) {
                Text(
                    text = if (wallPass) "[ WALL: WRAP ]" else "[ WALL: SOLID ]",
                    fontFamily = PixelFontFamily,
                    fontSize = 8.sp,
                    color = LcdPixel
                )
            }
        }
    }
}

/**
 * Paused screen overlay.
 */
@Composable
private fun LcdPausedOverlay(
    score: Int,
    onResume: () -> Unit,
    blinkAlpha: Float
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(LcdBackground.copy(alpha = 0.90f)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "PAUSED",
                fontFamily = PixelFontFamily,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = LcdPixel,
                modifier = Modifier.padding(bottom = 6.dp)
            )

            Text(
                text = "SCORE: %04d".format(score),
                fontFamily = PixelFontFamily,
                fontSize = 10.sp,
                color = LcdPixel,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            Text(
                text = "▶ TAP TO RESUME ◀",
                fontFamily = PixelFontFamily,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = LcdPixel.copy(alpha = blinkAlpha),
                modifier = Modifier
                    .clickable(onClick = onResume)
                    .testTag("lcd_resume_prompt")
            )
        }
    }
}

/**
 * Game Over overlay with final score, best score, and retry button.
 */
@Composable
private fun LcdGameOverOverlay(
    score: Int,
    highScore: Int,
    isNewRecord: Boolean,
    onRestart: () -> Unit,
    blinkAlpha: Float
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(LcdBackground.copy(alpha = 0.92f)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "GAME OVER",
                fontFamily = PixelFontFamily,
                fontSize = 16.sp,
                fontWeight = FontWeight.ExtraBold,
                color = LcdPixel,
                modifier = Modifier.padding(bottom = 6.dp)
            )

            if (isNewRecord) {
                Text(
                    text = "★ NEW HIGH SCORE! ★",
                    fontFamily = PixelFontFamily,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold,
                    color = LcdPixel.copy(alpha = blinkAlpha),
                    modifier = Modifier.padding(bottom = 4.dp)
                )
            }

            Text(
                text = "FINAL: %04d".format(score),
                fontFamily = PixelFontFamily,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = LcdPixel,
                modifier = Modifier.padding(bottom = 2.dp)
            )

            Text(
                text = "BEST : %04d".format(highScore),
                fontFamily = PixelFontFamily,
                fontSize = 9.sp,
                color = LcdPixel,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            Text(
                text = "▶ PLAY AGAIN ◀",
                fontFamily = PixelFontFamily,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = LcdPixel.copy(alpha = blinkAlpha),
                modifier = Modifier
                    .clip(RoundedCornerShape(3.dp))
                    .background(LcdPixelInactive)
                    .clickable(onClick = onRestart)
                    .padding(horizontal = 8.dp, vertical = 4.dp)
                    .testTag("lcd_restart_prompt")
            )
        }
    }
}

/**
 * Draws retro LCD grid dots across the background.
 */
private fun DrawScope.drawLcdGridDots(
    width: Int,
    height: Int,
    cellW: Float,
    cellH: Float,
    dotColor: Color
) {
    val dotRadius = 1f
    for (x in 0 until width) {
        for (y in 0 until height) {
            drawCircle(
                color = dotColor,
                radius = dotRadius,
                center = Offset(x * cellW + cellW / 2, y * cellH + cellH / 2)
            )
        }
    }
}

/**
 * Draws a single snake segment. If head, draws the Nokia-style eyes in direction of movement.
 */
private fun DrawScope.drawSnakeSegment(
    left: Float,
    top: Float,
    width: Float,
    height: Float,
    isHead: Boolean,
    direction: Direction,
    color: Color
) {
    val padding = 1f
    val segW = (width - padding * 2).coerceAtLeast(1f)
    val segH = (height - padding * 2).coerceAtLeast(1f)

    drawRect(
        color = color,
        topLeft = Offset(left + padding, top + padding),
        size = Size(segW, segH)
    )

    // Draw snake eyes on the head
    if (isHead) {
        val eyeSize = (width / 5f).coerceAtLeast(1.5f)
        val eyeColor = LcdBackground // Negative cutout eye

        when (direction) {
            Direction.RIGHT -> {
                drawRect(
                    color = eyeColor,
                    topLeft = Offset(left + segW - eyeSize, top + segH * 0.25f),
                    size = Size(eyeSize, eyeSize)
                )
                drawRect(
                    color = eyeColor,
                    topLeft = Offset(left + segW - eyeSize, top + segH * 0.75f - eyeSize),
                    size = Size(eyeSize, eyeSize)
                )
            }
            Direction.LEFT -> {
                drawRect(
                    color = eyeColor,
                    topLeft = Offset(left + padding + eyeSize * 0.5f, top + segH * 0.25f),
                    size = Size(eyeSize, eyeSize)
                )
                drawRect(
                    color = eyeColor,
                    topLeft = Offset(left + padding + eyeSize * 0.5f, top + segH * 0.75f - eyeSize),
                    size = Size(eyeSize, eyeSize)
                )
            }
            Direction.UP -> {
                drawRect(
                    color = eyeColor,
                    topLeft = Offset(left + segW * 0.25f, top + padding + eyeSize * 0.5f),
                    size = Size(eyeSize, eyeSize)
                )
                drawRect(
                    color = eyeColor,
                    topLeft = Offset(left + segW * 0.75f - eyeSize, top + padding + eyeSize * 0.5f),
                    size = Size(eyeSize, eyeSize)
                )
            }
            Direction.DOWN -> {
                drawRect(
                    color = eyeColor,
                    topLeft = Offset(left + segW * 0.25f, top + segH - eyeSize),
                    size = Size(eyeSize, eyeSize)
                )
                drawRect(
                    color = eyeColor,
                    topLeft = Offset(left + segW * 0.75f - eyeSize, top + segH - eyeSize),
                    size = Size(eyeSize, eyeSize)
                )
            }
        }
    }
}

/**
 * Draws the retro square food with Nokia LCD pixel style.
 */
private fun DrawScope.drawLcdFood(
    left: Float,
    top: Float,
    width: Float,
    height: Float,
    color: Color,
    blink: Boolean
) {
    val padding = 1.5f
    val fWidth = (width - padding * 2).coerceAtLeast(2f)
    val fHeight = (height - padding * 2).coerceAtLeast(2f)

    // Outer pixel box
    drawRect(
        color = color,
        topLeft = Offset(left + padding, top + padding),
        size = Size(fWidth, fHeight)
    )

    // Center cutout to make it look like a classic Nokia apple / bug
    val innerPad = (fWidth / 3.5f).coerceAtLeast(1.5f)
    drawRect(
        color = LcdBackground,
        topLeft = Offset(left + padding + innerPad, top + padding + innerPad),
        size = Size(fWidth - innerPad * 2, fHeight - innerPad * 2)
    )
}
