package com.example.snake.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.snake.model.Direction
import com.example.snake.model.GameStatus
import com.example.ui.theme.KeypadAccent
import com.example.ui.theme.KeypadAccentAmber
import com.example.ui.theme.KeypadButtonDark
import com.example.ui.theme.KeypadButtonLight
import com.example.ui.theme.KeypadButtonText
import com.example.ui.theme.PhoneBezel
import com.example.ui.theme.PhoneBodyNavy
import com.example.ui.theme.PhoneSilverTrim
import com.example.ui.theme.PixelFontFamily

/**
 * Nostalgic tactile phone keypad containing:
 * - Function soft keys (Start/Pause, Restart, Sound, Haptic)
 * - Ergonomic 4-way D-pad (Up, Down, Left, Right)
 * - Classic Nokia 12-key numeric pad with 2/4/6/8 direction mappings
 */
@Composable
fun PhoneKeypad(
    gameStatus: GameStatus,
    soundEnabled: Boolean,
    hapticsEnabled: Boolean,
    onDirectionClick: (Direction) -> Unit,
    onStartClick: () -> Unit,
    onPauseClick: () -> Unit,
    onResumeClick: () -> Unit,
    onRestartClick: () -> Unit,
    onToggleSound: () -> Unit,
    onToggleHaptics: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Soft Function Keys Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Main Action Button (Start / Pause / Resume)
            SoftKeyButton(
                label = when (gameStatus) {
                    GameStatus.IDLE -> "START"
                    GameStatus.RUNNING -> "PAUSE"
                    GameStatus.PAUSED -> "RESUME"
                    GameStatus.GAME_OVER -> "PLAY"
                },
                icon = when (gameStatus) {
                    GameStatus.RUNNING -> Icons.Default.Pause
                    else -> Icons.Default.PlayArrow
                },
                highlightColor = KeypadAccent,
                onClick = {
                    when (gameStatus) {
                        GameStatus.IDLE -> onStartClick()
                        GameStatus.RUNNING -> onPauseClick()
                        GameStatus.PAUSED -> onResumeClick()
                        GameStatus.GAME_OVER -> onRestartClick()
                    }
                },
                testTag = "softkey_primary"
            )

            // Middle utility toggles (Sound & Haptics)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                UtilityPillButton(
                    icon = if (soundEnabled) Icons.Default.VolumeUp else Icons.Default.VolumeMute,
                    isActive = soundEnabled,
                    contentDescription = if (soundEnabled) "Mute Sound" else "Enable Sound",
                    onClick = onToggleSound,
                    testTag = "toggle_sound_btn"
                )

                UtilityPillButton(
                    icon = Icons.Default.Vibration,
                    isActive = hapticsEnabled,
                    contentDescription = if (hapticsEnabled) "Disable Haptics" else "Enable Haptics",
                    onClick = onToggleHaptics,
                    testTag = "toggle_haptics_btn"
                )
            }

            // Restart / Reset Soft Key
            SoftKeyButton(
                label = "RESET",
                icon = Icons.Default.Refresh,
                highlightColor = KeypadAccentAmber,
                onClick = onRestartClick,
                testTag = "softkey_reset"
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // D-Pad and Numeric Controls Layout
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // 4-Way Tactile D-Pad
            DPadController(
                onDirectionClick = onDirectionClick,
                onCenterClick = {
                    when (gameStatus) {
                        GameStatus.IDLE -> onStartClick()
                        GameStatus.RUNNING -> onPauseClick()
                        GameStatus.PAUSED -> onResumeClick()
                        GameStatus.GAME_OVER -> onRestartClick()
                    }
                }
            )

            // Retro Nokia 12-key Pad (with 2,4,6,8 directional support)
            NokiaNumericPad(
                onDirectionClick = onDirectionClick,
                onStartClick = {
                    if (gameStatus == GameStatus.RUNNING) onPauseClick() else onStartClick()
                }
            )
        }
    }
}

/**
 * Prominent 4-Way D-Pad with raised 3D tactile buttons.
 */
@Composable
private fun DPadController(
    onDirectionClick: (Direction) -> Unit,
    onCenterClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .size(150.dp)
            .clip(CircleShape)
            .background(PhoneBezel)
            .border(2.dp, PhoneSilverTrim.copy(alpha = 0.5f), CircleShape)
            .padding(4.dp),
        contentAlignment = Alignment.Center
    ) {
        // UP Button
        TactileDirectionButton(
            icon = Icons.Default.KeyboardArrowUp,
            contentDescription = "Move Up",
            modifier = Modifier
                .align(Alignment.TopCenter)
                .testTag("dpad_up"),
            onClick = { onDirectionClick(Direction.UP) }
        )

        // DOWN Button
        TactileDirectionButton(
            icon = Icons.Default.KeyboardArrowDown,
            contentDescription = "Move Down",
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .testTag("dpad_down"),
            onClick = { onDirectionClick(Direction.DOWN) }
        )

        // LEFT Button
        TactileDirectionButton(
            icon = Icons.Default.KeyboardArrowLeft,
            contentDescription = "Move Left",
            modifier = Modifier
                .align(Alignment.CenterStart)
                .testTag("dpad_left"),
            onClick = { onDirectionClick(Direction.LEFT) }
        )

        // RIGHT Button
        TactileDirectionButton(
            icon = Icons.Default.KeyboardArrowRight,
            contentDescription = "Move Right",
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .testTag("dpad_right"),
            onClick = { onDirectionClick(Direction.RIGHT) }
        )

        // Center OK / Action Button
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(
                    Brush.verticalGradient(
                        listOf(KeypadButtonLight, KeypadButtonDark)
                    )
                )
                .border(1.5.dp, KeypadAccent.copy(alpha = 0.7f), CircleShape)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = ripple(color = KeypadAccent),
                    onClick = onCenterClick
                )
                .testTag("dpad_center"),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "OK",
                fontFamily = PixelFontFamily,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = KeypadAccent
            )
        }
    }
}

/**
 * Individual directional tactile button with minimum 48dp touch target.
 */
@Composable
private fun TactileDirectionButton(
    icon: ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .size(48.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(
                Brush.verticalGradient(
                    listOf(KeypadButtonLight, KeypadButtonDark)
                )
            )
            .border(1.dp, PhoneSilverTrim.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple(color = KeypadAccent),
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = KeypadButtonText,
            modifier = Modifier.size(30.dp)
        )
    }
}

/**
 * Authentic Nokia 12-key numeric dial pad.
 * Keys 2, 4, 6, 8 serve as active arrow keys for true vintage Nokia Snake muscle memory!
 */
@Composable
private fun NokiaNumericPad(
    onDirectionClick: (Direction) -> Unit,
    onStartClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(PhoneBezel.copy(alpha = 0.7f))
            .padding(6.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Row 1: 1, 2(UP), 3
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            NokiaKey(num = "1", sub = "")
            NokiaKey(
                num = "2",
                sub = "▲",
                isActionKey = true,
                onClick = { onDirectionClick(Direction.UP) },
                testTag = "key_2_up"
            )
            NokiaKey(num = "3", sub = "def")
        }

        // Row 2: 4(LEFT), 5(OK), 6(RIGHT)
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            NokiaKey(
                num = "4",
                sub = "◄",
                isActionKey = true,
                onClick = { onDirectionClick(Direction.LEFT) },
                testTag = "key_4_left"
            )
            NokiaKey(
                num = "5",
                sub = "OK",
                isActionKey = true,
                onClick = onStartClick,
                testTag = "key_5_ok"
            )
            NokiaKey(
                num = "6",
                sub = "►",
                isActionKey = true,
                onClick = { onDirectionClick(Direction.RIGHT) },
                testTag = "key_6_right"
            )
        }

        // Row 3: 7, 8(DOWN), 9
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            NokiaKey(num = "7", sub = "pqrs")
            NokiaKey(
                num = "8",
                sub = "▼",
                isActionKey = true,
                onClick = { onDirectionClick(Direction.DOWN) },
                testTag = "key_8_down"
            )
            NokiaKey(num = "9", sub = "wxyz")
        }

        // Row 4: *, 0, #
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            NokiaKey(num = "*", sub = "+")
            NokiaKey(num = "0", sub = " ")
            NokiaKey(num = "#", sub = "⇧")
        }
    }
}

/**
 * Individual key on the Nokia numeric keypad.
 */
@Composable
private fun NokiaKey(
    num: String,
    sub: String,
    isActionKey: Boolean = false,
    onClick: (() -> Unit)? = null,
    testTag: String = ""
) {
    val tagModifier = if (testTag.isNotEmpty()) Modifier.testTag(testTag) else Modifier
    Box(
        modifier = Modifier
            .size(width = 44.dp, height = 34.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(
                if (isActionKey) {
                    Brush.verticalGradient(listOf(KeypadButtonLight, KeypadButtonDark))
                } else {
                    Brush.verticalGradient(listOf(PhoneBodyNavy, KeypadButtonDark))
                }
            )
            .border(
                1.dp,
                if (isActionKey) KeypadAccent.copy(alpha = 0.5f) else PhoneSilverTrim.copy(alpha = 0.2f),
                RoundedCornerShape(6.dp)
            )
            .then(
                if (onClick != null) {
                    Modifier.clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = ripple(color = KeypadAccent),
                        onClick = onClick
                    )
                } else {
                    Modifier
                }
            )
            .then(tagModifier),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = num,
                fontFamily = PixelFontFamily,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = if (isActionKey) KeypadAccent else KeypadButtonText
            )
            if (sub.isNotEmpty()) {
                Text(
                    text = sub,
                    fontFamily = PixelFontFamily,
                    fontSize = 7.sp,
                    color = if (isActionKey) KeypadAccent else KeypadButtonText.copy(alpha = 0.6f)
                )
            }
        }
    }
}

/**
 * Top soft keys with retro styling.
 */
@Composable
private fun SoftKeyButton(
    label: String,
    icon: ImageVector,
    highlightColor: Color,
    onClick: () -> Unit,
    testTag: String
) {
    Box(
        modifier = Modifier
            .size(width = 100.dp, height = 44.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(
                Brush.verticalGradient(
                    listOf(KeypadButtonLight, KeypadButtonDark)
                )
            )
            .border(1.5.dp, highlightColor.copy(alpha = 0.6f), RoundedCornerShape(10.dp))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple(color = highlightColor),
                onClick = onClick
            )
            .testTag(testTag)
            .padding(horizontal = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = highlightColor,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                fontFamily = PixelFontFamily,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = KeypadButtonText
            )
        }
    }
}

/**
 * Compact pill button for audio / haptic toggles.
 */
@Composable
private fun UtilityPillButton(
    icon: ImageVector,
    isActive: Boolean,
    contentDescription: String,
    onClick: () -> Unit,
    testTag: String
) {
    Box(
        modifier = Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(if (isActive) KeypadButtonLight else PhoneBezel)
            .border(
                1.dp,
                if (isActive) KeypadAccent.copy(alpha = 0.7f) else PhoneSilverTrim.copy(alpha = 0.2f),
                CircleShape
            )
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple(color = KeypadAccent),
                onClick = onClick
            )
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = if (isActive) KeypadAccent else KeypadButtonText.copy(alpha = 0.4f),
            modifier = Modifier.size(20.dp)
        )
    }
}
