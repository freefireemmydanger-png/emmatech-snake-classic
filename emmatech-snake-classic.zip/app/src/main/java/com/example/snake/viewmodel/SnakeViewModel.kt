package com.example.snake.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.snake.audio.RetroAudioHelper
import com.example.snake.data.SnakePreferences
import com.example.snake.model.Coordinate
import com.example.snake.model.Difficulty
import com.example.snake.model.Direction
import com.example.snake.model.GameStatus
import com.example.snake.model.SnakeGameState
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.LinkedList
import kotlin.random.Random

/**
 * ViewModel managing the game loop, snake mechanics, collisions, sound and high scores.
 */
class SnakeViewModel(application: Application) : AndroidViewModel(application) {

    private val preferences = SnakePreferences(application)
    val audioHelper = RetroAudioHelper(application)

    private val _gameState = MutableStateFlow(
        SnakeGameState(
            highScore = preferences.getHighScore(),
            soundEnabled = preferences.isSoundEnabled(),
            hapticsEnabled = preferences.isHapticsEnabled(),
            wallPassThrough = preferences.isWallPassThrough(),
            difficulty = try {
                Difficulty.valueOf(preferences.getDifficulty())
            } catch (e: Exception) {
                Difficulty.CLASSIC
            }
        )
    )
    val gameState: StateFlow<SnakeGameState> = _gameState.asStateFlow()

    // Input buffer to allow rapid successive turns without skipping or self-collision
    private val inputQueue = LinkedList<Direction>()
    private var gameLoopJob: Job? = null

    init {
        resetGameToIdle()
    }

    /**
     * Initializes or resets the snake and food to default positions.
     */
    fun resetGameToIdle() {
        gameLoopJob?.cancel()
        inputQueue.clear()

        val defaultSnake = listOf(
            Coordinate(8, 10),
            Coordinate(7, 10),
            Coordinate(6, 10),
            Coordinate(5, 10)
        )
        val initialFood = generateFood(defaultSnake, _gameState.value.gridWidth, _gameState.value.gridHeight)

        _gameState.update {
            it.copy(
                snake = defaultSnake,
                currentDirection = Direction.RIGHT,
                food = initialFood,
                status = GameStatus.IDLE,
                score = 0,
                isNewHighScore = false
            )
        }
    }

    /**
     * Starts or restarts the active game loop.
     */
    fun startGame() {
        if (_gameState.value.status == GameStatus.RUNNING) return

        if (_gameState.value.status == GameStatus.GAME_OVER) {
            resetGameToIdle()
        }

        if (_gameState.value.soundEnabled) audioHelper.playButtonClickSound()
        if (_gameState.value.hapticsEnabled) audioHelper.vibrateKeyClick()

        _gameState.update { it.copy(status = GameStatus.RUNNING) }
        launchGameLoop()
    }

    /**
     * Pauses the game if currently running.
     */
    fun pauseGame() {
        if (_gameState.value.status == GameStatus.RUNNING) {
            gameLoopJob?.cancel()
            _gameState.update { it.copy(status = GameStatus.PAUSED) }
            if (_gameState.value.soundEnabled) audioHelper.playButtonClickSound()
            if (_gameState.value.hapticsEnabled) audioHelper.vibrateKeyClick()
        }
    }

    /**
     * Resumes the paused game.
     */
    fun resumeGame() {
        if (_gameState.value.status == GameStatus.PAUSED) {
            _gameState.update { it.copy(status = GameStatus.RUNNING) }
            if (_gameState.value.soundEnabled) audioHelper.playButtonClickSound()
            if (_gameState.value.hapticsEnabled) audioHelper.vibrateKeyClick()
            launchGameLoop()
        }
    }

    /**
     * Restarts a fresh game immediately into running state.
     */
    fun restartGame() {
        resetGameToIdle()
        startGame()
    }

    /**
     * Handles directional input with reversal protection and queueing.
     */
    fun handleDirectionInput(requestedDirection: Direction) {
        val state = _gameState.value
        if (state.status != GameStatus.RUNNING) {
            if (state.status == GameStatus.IDLE) {
                startGame()
            }
            return
        }

        // Determine the reference direction: either the last buffered direction or current active direction
        val referenceDir = if (inputQueue.isNotEmpty()) inputQueue.last else state.currentDirection

        // Disallow reversing directly into itself
        if (requestedDirection != referenceDir && !requestedDirection.isOpposite(referenceDir)) {
            if (inputQueue.size < 2) {
                inputQueue.add(requestedDirection)
                if (state.soundEnabled) audioHelper.playTurnSound()
                if (state.hapticsEnabled) audioHelper.vibrateKeyClick()
            }
        }
    }

    /**
     * Executes one game step: moves snake, checks collisions, updates score.
     */
    fun tick() {
        val state = _gameState.value
        if (state.status != GameStatus.RUNNING) return

        // Pop next direction from queue if available
        val nextDirection = if (inputQueue.isNotEmpty()) {
            inputQueue.poll()!!
        } else {
            state.currentDirection
        }

        val head = state.snake.first()
        var newHeadX = head.x + nextDirection.dx
        var newHeadY = head.y + nextDirection.dy

        // Wall collision check
        val isOutOfBounds = newHeadX < 0 || newHeadX >= state.gridWidth ||
                newHeadY < 0 || newHeadY >= state.gridHeight

        if (isOutOfBounds) {
            if (state.wallPassThrough) {
                newHeadX = (newHeadX + state.gridWidth) % state.gridWidth
                newHeadY = (newHeadY + state.gridHeight) % state.gridHeight
            } else {
                handleGameOver()
                return
            }
        }

        val newHead = Coordinate(newHeadX, newHeadY)

        // Self-collision check
        // If snake isn't eating food, the tail will move forward so colliding with the current tail is allowed.
        val isEatingFood = newHead == state.food
        val bodyToCheck = if (isEatingFood) state.snake else state.snake.dropLast(1)
        if (bodyToCheck.contains(newHead)) {
            handleGameOver()
            return
        }

        // Advance snake
        val newSnake = mutableListOf(newHead)
        newSnake.addAll(state.snake)
        if (!isEatingFood) {
            newSnake.removeAt(newSnake.size - 1)
        }

        if (isEatingFood) {
            val newScore = state.score + 1
            var isNewRecord = false
            var currentHigh = state.highScore

            if (newScore > currentHigh) {
                currentHigh = newScore
                isNewRecord = true
                preferences.saveHighScore(currentHigh)
            }

            val nextFood = generateFood(newSnake, state.gridWidth, state.gridHeight)

            if (state.soundEnabled) audioHelper.playFoodSound()
            if (state.hapticsEnabled) audioHelper.vibrateEatFood()

            _gameState.update {
                it.copy(
                    snake = newSnake,
                    currentDirection = nextDirection,
                    food = nextFood,
                    score = newScore,
                    highScore = currentHigh,
                    isNewHighScore = isNewRecord
                )
            }
        } else {
            _gameState.update {
                it.copy(
                    snake = newSnake,
                    currentDirection = nextDirection
                )
            }
        }
    }

    private fun handleGameOver() {
        gameLoopJob?.cancel()
        val currentHigh = preferences.getHighScore()
        val currentScore = _gameState.value.score
        val isRecord = currentScore > currentHigh
        if (isRecord) {
            preferences.saveHighScore(currentScore)
        }

        if (_gameState.value.soundEnabled) audioHelper.playGameOverSound()
        if (_gameState.value.hapticsEnabled) audioHelper.vibrateGameOver()

        _gameState.update {
            it.copy(
                status = GameStatus.GAME_OVER,
                highScore = maxOf(currentHigh, currentScore),
                isNewHighScore = isRecord
            )
        }
    }

    private fun launchGameLoop() {
        gameLoopJob?.cancel()
        gameLoopJob = viewModelScope.launch {
            while (isActive && _gameState.value.status == GameStatus.RUNNING) {
                delay(_gameState.value.currentDelayMs)
                tick()
            }
        }
    }

    private fun generateFood(snake: List<Coordinate>, width: Int, height: Int): Coordinate {
        val snakeSet = snake.toSet()
        val totalCells = width * height
        if (snakeSet.size >= totalCells) {
            return Coordinate(0, 0) // Board full
        }

        // Fast random placement with fallback
        for (i in 0 until 50) {
            val rx = Random.nextInt(width)
            val ry = Random.nextInt(height)
            val coord = Coordinate(rx, ry)
            if (!snakeSet.contains(coord)) {
                return coord
            }
        }

        // Complete free cells search if board gets crowded
        val freeCells = mutableListOf<Coordinate>()
        for (x in 0 until width) {
            for (y in 0 until height) {
                val candidate = Coordinate(x, y)
                if (!snakeSet.contains(candidate)) {
                    freeCells.add(candidate)
                }
            }
        }
        return if (freeCells.isNotEmpty()) {
            freeCells[Random.nextInt(freeCells.size)]
        } else {
            Coordinate(0, 0)
        }
    }

    fun toggleSound() {
        val newSound = !_gameState.value.soundEnabled
        preferences.setSoundEnabled(newSound)
        _gameState.update { it.copy(soundEnabled = newSound) }
        if (newSound) audioHelper.playButtonClickSound()
    }

    fun toggleHaptics() {
        val newHaptics = !_gameState.value.hapticsEnabled
        preferences.setHapticsEnabled(newHaptics)
        _gameState.update { it.copy(hapticsEnabled = newHaptics) }
        if (newHaptics) audioHelper.vibrateKeyClick()
    }

    fun toggleWallPassThrough() {
        val newWall = !_gameState.value.wallPassThrough
        preferences.setWallPassThrough(newWall)
        _gameState.update { it.copy(wallPassThrough = newWall) }
    }

    fun setDifficulty(difficulty: Difficulty) {
        preferences.setDifficulty(difficulty.name)
        _gameState.update { it.copy(difficulty = difficulty) }
    }

    fun resetHighScore() {
        preferences.resetHighScore()
        _gameState.update { it.copy(highScore = 0, isNewHighScore = false) }
    }

    override fun onCleared() {
        super.onCleared()
        gameLoopJob?.cancel()
        audioHelper.release()
    }
}
