package com.example

import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.snake.data.SnakePreferences
import com.example.snake.model.Coordinate
import com.example.snake.model.Difficulty
import com.example.snake.model.Direction
import com.example.snake.model.GameStatus
import com.example.snake.model.SnakeGameState
import com.example.snake.viewmodel.SnakeViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("EMMATECH Snake Classic", appName)
    }

    @Test
    fun `test snake cannot reverse directly into itself`() {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val viewModel = SnakeViewModel(app)

        viewModel.startGame()
        assertEquals(Direction.RIGHT, viewModel.gameState.value.currentDirection)

        // Requesting LEFT while moving RIGHT should be ignored
        viewModel.handleDirectionInput(Direction.LEFT)
        assertEquals(Direction.RIGHT, viewModel.gameState.value.currentDirection)

        // Turning UP is valid
        viewModel.handleDirectionInput(Direction.UP)
        viewModel.tick()
        assertEquals(Direction.UP, viewModel.gameState.value.currentDirection)

        // Requesting DOWN while moving UP should be ignored
        viewModel.handleDirectionInput(Direction.DOWN)
        assertEquals(Direction.UP, viewModel.gameState.value.currentDirection)
    }

    @Test
    fun `test snake movement advances head and body`() {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val viewModel = SnakeViewModel(app)

        viewModel.startGame()
        val initialHead = viewModel.gameState.value.snake.first()
        viewModel.tick()
        val newHead = viewModel.gameState.value.snake.first()

        assertEquals(initialHead.x + 1, newHead.x)
        assertEquals(initialHead.y, newHead.y)
    }

    @Test
    fun `test high score persistence`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val prefs = SnakePreferences(context)
        prefs.resetHighScore()
        assertEquals(0, prefs.getHighScore())

        prefs.saveHighScore(12)
        assertEquals(12, prefs.getHighScore())

        // Saving smaller score should not overwrite
        prefs.saveHighScore(8)
        assertEquals(12, prefs.getHighScore())

        // Saving higher score should update
        prefs.saveHighScore(25)
        assertEquals(25, prefs.getHighScore())
    }

    @Test
    fun `test difficulty speed escalation`() {
        val stateBase = SnakeGameState(score = 0, difficulty = Difficulty.CLASSIC)
        val stateHigher = SnakeGameState(score = 10, difficulty = Difficulty.CLASSIC)

        assertTrue(stateHigher.currentDelayMs < stateBase.currentDelayMs)
    }
}
